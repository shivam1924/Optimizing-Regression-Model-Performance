import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.linear_model import Lasso
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import mean_squared_error, mean_absolute_error

data = pd.read_csv(r"C:\Users\Amit\Desktop\100_Sales.csv")
data = data.drop(columns=['Unnamed: 9', 'Unnamed: 10'])
X = data.drop(columns=['Total_Revenue'])  
y = data['Total_Revenue']
X = pd.get_dummies(X, drop_first=True)
scaler = StandardScaler()
X = scaler.fit_transform(X)
y = np.log1p(y)  
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

lasso = Lasso(max_iter=10000)
param_grid = {'alpha': np.linspace(0.0001, 0.1, 100)}
grid_search = GridSearchCV(lasso, param_grid, scoring='neg_mean_squared_error', cv=5)
grid_search.fit(X_train, y_train)
best_lasso = grid_search.best_estimator_
best_alpha = grid_search.best_params_['alpha']
print(f"Optimal alpha: {best_alpha}")

y_pred_log = best_lasso.predict(X_test)
y_pred = np.expm1(y_pred_log)  
y_test = np.expm1(y_test)      
mse = mean_squared_error(y_test, y_pred)
mae = mean_absolute_error(y_test, y_pred)
rmse = np.sqrt(mse)
def min_max_scale(value, min_value, max_value, new_min=0, new_max=12):
    return ((value - min_value) / (max_value - min_value)) * (new_max - new_min) + new_min
mse_min = 0  
mse_max = 1e12  
mae_min = 0  
mae_max = 1e6  
rmse_min = 0  
rmse_max = 1e6  
scaled_mse = min_max_scale(mse, mse_min, mse_max)
scaled_mae = min_max_scale(mae, mae_min, mae_max)
scaled_rmse = min_max_scale(rmse, rmse_min, rmse_max)
print(f"Original Mean Squared Error (MSE): {mse}")
print(f"Original Mean Absolute Error (MAE): {mae}")
print(f"Original Root Mean Squared Error (RMSE): {rmse}")

print(f"Scaled Mean Squared Error (MSE) [0-12]: {scaled_mse}")
print(f"Scaled Mean Absolute Error (MAE) [0-12]: {scaled_mae}")
print(f"Scaled Root Mean Squared Error (RMSE) [0-12]: {scaled_rmse}")
if 0 <= scaled_mse <= 12 and 0 <= scaled_mae <= 12 and 0 <= scaled_rmse <= 12:
    print("The metrics are within the desired range.")
else:
    print("The metrics are outside the desired range.")

